from pathlib import Path
from PIL import Image,ImageDraw
import json,subprocess,zipfile
p=Path(__file__).parent;old=p.parent/'rifle115-v4-scale2'
changes={}
for k,scale,anchor in [('4',1.3,(279,266)),('R',.4,(285,270))]:
 src=Image.open(old/f'{k}-equipment.png').convert('RGBA');box=src.getbbox();crop=src.crop(box);crop=crop.resize((round(crop.width*scale),round(crop.height*scale)),Image.Resampling.LANCZOS)
 layer=Image.new('RGBA',src.size);layer.alpha_composite(crop,(round(anchor[0]+scale*(box[0]-anchor[0])),round(anchor[1]+scale*(box[1]-anchor[1]))));layer.save(p/f'{k}-equipment.png')
 im=Image.open(p/f'{k}-backing.png').convert('RGBA');im.alpha_composite(layer);im.alpha_composite(Image.open(p/f'{k}-hands.png').convert('RGBA'));im.save(p/f'{k}.png');changes[k]={'scaleVsV4':scale,'anchor':anchor,'bbox':layer.getbbox()}
qa={'changes':changes,'unchangedStates':{},'backingHandsExact':{},'review':'Static and decoded frames, not continuous playback','newGeneration':False,'RIdentity':'approved weapon4 substitute'}
for k in ['0','1','2','4','R']:
 for s in ['backing','hands']:qa['backingHandsExact'][k+'-'+s]=(p/f'{k}-{s}.png').read_bytes()==(old/f'{k}-{s}.png').read_bytes()
 if k not in ['4','R']:qa['unchangedStates'][k]=(p/f'{k}.png').read_bytes()==(old/f'{k}.png').read_bytes()
order=[]
for k,n in zip(['0','1','2','4','R','4','2','1','0'],[8,3,3,4,2,3,4,4,12]):order += [k]*n
for i,k in enumerate(order):
 im=Image.open(p/f'{k}.png');bg=Image.new('RGBA',im.size,(70,75,80,255));bg.alpha_composite(im);ImageDraw.Draw(bg).text((18,18),f'115 SOUTH V5 | quadro {k} | 4: +30% | R: -60%',fill='white');bg.convert('RGB').save(p/f'video-{i:03}.png')
subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate','24','-i',str(p/'video-%03d.png'),'-vf','loop=loop=3:size=43:start=0','-frames:v','172','-c:v','libx264','-pix_fmt','yuv420p',str(p/'Rifle115_SOUTH_V5_Proporcoes.mp4')],check=True)
(p/'QA.json').write_text(json.dumps(qa,indent=2));(p/'README.txt').write_text('115 SOUTH V5. Artes existentes apenas. Estado R:40% do tamanho V4, reducao60%. Estado4:130% do tamanho V4, aumento30%, para espessura visual mais proxima. Personagem e maos exatos; estados0/1/2 exatos. R continua substituto aprovado4, nao nova vista axial115. Frames1-based em cada43:4=15-18 e21-23; R=19-20. Preview nao integrado.\n')
subprocess.run(['python',str(p/'RESTORE.py')],check=True)
with zipfile.ZipFile(p.parent/'Rifle115_SOUTH_V5_Proporcoes_Editavel.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in p.iterdir():
  if not f.name.startswith(('video-','restored-')):z.write(f,f.name)
print(qa)
