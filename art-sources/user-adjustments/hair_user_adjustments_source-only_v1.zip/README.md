# hair: fontes e ajustes técnicos
SOURCE-ONLY. Não são sprites finais nem renders visualmente aprovados. Este pacote não pertence ao catálogo de arte aprovada.

Contém 27 registros de ajustes fornecidos, o catálogo técnico de contexto (12 entradas), 94 PNGs originais de camadas e módulos de prévia. Os valores dos ajustes, encaixes, geometria, ordem de camadas e políticas foram preservados. O catálogo pode incluir estados de contexto sem ajuste fornecido: não confundir esses estados com instruções adicionais ou aprovação visual. Não foram acrescentados ajustes normalizados pelo editor.

Os PNGs foram extraídos das fontes embutidas sem recodificação; os nomes são seus SHA-256. asset-map.json associa as referências de camadas aos arquivos. preview.js e presets.js são módulos originais; workbench contém o compositor e a máscara de cabelo correspondentes. Não inclui aplicativo pronto nem novos renders.

Removidos apenas metadados de data, caminhos de origem, relatos e anotações não operacionais. Os identificadores packSHA256/snapshot e catalogSHA256/sha256 permanecem como chaves técnicas históricas de correspondência, não como hashes dos JSONs sanitizados. Consulte SHA256.json para os hashes dos arquivos deste pacote. Os registros de ajustes permanecem semanticamente idênticos aos recebidos.

Não há certificação de aprovação visual de combinações, nem de animação, nem dos testes de reprodução anteriores. Nenhuma arte foi redesenhada.
