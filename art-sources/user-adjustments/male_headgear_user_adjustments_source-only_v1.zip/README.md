# Fontes e ajustes técnicos masculinos
Arquivo técnico editável: 408 ajustes fornecidos, 120 entradas de catálogo de contexto e 116 PNGs originais. Não contém novos renders ou animações. Não é um aplicativo pronto.

Todos os targets, snapshots, packSHA256 e direções dos ajustes estão vinculados ao catálogo exato, cuja identidade canônica foi verificada antes da sanitização. hideHair foi preservado em todos os registros. Os valores técnicos dos ajustes e dos catálogos foram mantidos. Não se acrescentaram registros normalizados nem se aplicaram ajustes não fornecidos.

Os PNGs preservam os bytes originais sem recodificação; seus nomes são SHA-256. asset-map.json resolve referências das camadas. Os módulos originais presets.js e preview.js usam runtime/compositor.js e runtime/hair-mask.js. Ajustes permanecem separados das camadas para aplicação por um consumidor compatível. Entradas de contexto sem ajuste fornecido não significam nova instrução de ajuste.

Metadados de data, caminhos e anotações não operacionais foram removidos. catalogSHA256/sha256 e snapshot/packSHA256 são identidades históricas para compatibilidade, não hashes dos JSONs sanitizados. TARGET_MAP.json documenta o vínculo técnico; SHA256.json verifica os arquivos distribuídos. O vínculo ao catálogo não é uma certificação visual nem uma aprovação de novos renders.
