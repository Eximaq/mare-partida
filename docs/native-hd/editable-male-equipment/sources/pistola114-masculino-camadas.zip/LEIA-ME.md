# Pistola 114 · masculino
Material local, não publicado. Camadas de equipamento RGBA 640 × 640, com registro pela origem do quadro.

- Sul: Calças 21 e 22, Bota 9 (cano traseiro/frontal) e Luva 25. Teste do compositor local nas 30 posições do relógio original, com cabelo, olhos e pele personalizados. A luva Sul fica restrita ao ataque; a caminhada e a pose parada não são alteradas. Os dois quadros já aprovados permanecem idênticos.
- Norte: Calça 21, Bota 9 e Luva 25, compiladas localmente nas oito poses. Pequenos pontos de encaixe ainda podem ser visíveis.
- Leste e Oeste: Luva 25 + Calça 21 + Bota 9, com espelho conferido. As composições Norte e laterais foram testadas fora do jogo; não são prova de integração com o jogo nem de personalização nessas direções.
- Ordem: traseira do cano, corpo original, frente do cano, calça, luva. A Bota Norte tem arquivos 0/2 traseiros e 1/3 dianteiros. Verifique a lente de cores e fallback por peça no jogo antes de integrar.
