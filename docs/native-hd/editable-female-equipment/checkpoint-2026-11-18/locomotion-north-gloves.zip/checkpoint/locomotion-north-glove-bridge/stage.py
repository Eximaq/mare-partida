from pathlib import Path
import json,hashlib
D=Path(__file__).parent;R=D.parent.parent/'repo';text=(R/'player-rework-native-hd.js').read_text();a=text.index(' function resolveNorthLayers(');b=text.index(' function resolveSouthCarry(',a);part=text[a:b]
part=part.replace("['weapon','legs','pants'].includes(key)","['weapon','legs','pants','gloves'].includes(key)")
part=part.replace("const duration=", "const gloveId=equipment.gloves==null?null:Number(equipment.gloves.def??equipment.gloves); const glove=gloveId==null?null:northGloveLayers?.[gloveId]; if(gloveId!=null&&(!glove||item!=null))return null;\n  const duration=")
part=part.replace("':'+body.id,hdKind", "':'+body.id+':glove:'+gloveId,hdKind")
part=part.replace("northLayers:{spec:s,body,pants}","northLayers:{spec:s,body,pants,glove}")
part=part.replace("...femaleRegistry.requiredFiles(body,{frame:f}),", "...femaleRegistry.requiredFiles(body,{frame:f}),...(r.northLayers.glove||[]).map(l=>'tools/rework-modular-outfits-hd/assets/'+l.frames[f*5]+'.png'),")
part=part.replace("function northResult(canvas,info){const rgba", "function northResult(canvas,info){for(const l of r.northLayers.glove||[]){const im=images.get('tools/rework-modular-outfits-hd/assets/'+l.frames[phase*5]+'.png');if(!im)throw Error('Missing independent north glove');canvas.getContext('2d').drawImage(im,pad,pad);}const rgba")
text=text[:a]+part+text[b:]
# optional constructor option
needle='function create('
start=text.index(needle);print(text[start:start+250])
text=text.replace('function create({','function create({northGloveLayers,',1)
(D/'native-staged.cjs').write_text(text)
cat=json.loads((D.parent/'idle-walk-gloves-local/catalog.json').read_text()); rows={str(x['item']):x['gloveLayers'] for x in cat if x['action']=='walk' and x['direction']=='north' and not x['derived']}
(D/'layers.json').write_text(json.dumps(rows))
(D/'stage-proof.json').write_text(json.dumps({'originalSHA256':hashlib.sha256((R/'player-rework-native-hd.js').read_bytes()).hexdigest(),'ids':list(rows)},indent=2))
