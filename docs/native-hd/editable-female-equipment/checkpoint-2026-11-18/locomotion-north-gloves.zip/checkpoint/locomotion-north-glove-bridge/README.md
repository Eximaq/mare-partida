# Independent gloves on actual authored North walking

Local staging only. No repo edits, PR, public preview or per-color assets.

`create.cjs::create()` exposes actual Native `select` and `prepareConfiguration`; the test has no forced resolver. `stage.py` adds optional `northGloveLayers` injection into a copied Native module. It changes the special authored North compositor, not ignored raw pack layers.

Coverage: 10 own IDs (25,26,131,138,145,152,159,166,173,180), walk North with no weapon, with authored P21 or without pants. All 40 original ticks preserved. Existing authorial body, appearance and pants source unchanged. Each own historical glove has eight saved RGBA states (five repeated ticks in the old donor). Current source phaseMap selects its actual same original arm state; no new movement is generated, no image recolored, resized, cropped or repainted. Source alpha retains fingerless holes.

Proof:
- hand-proof: donor original-hand RGBA is exact subset of the real native arms in all phases except 2 near-black extraneous boundary pixels in phase1 at (303,241)/(303,242). All actual hand pixels coincide; no donor body is copied.
- occlusion-proof: all 10 gloves across 12 authored phases have ZERO alpha overlap with the existing authorial arm-occlusion mask.
- proof: 30 ordinary routes, 1560 Native draw calls including baseline/unequip, 40 ticks each. Original P21, original no pants, dark/bob/blonde P21. Every baseline and removal equals original Native RGBA exactly. Every changed pixel belongs to selected own glove alpha; original pack/body/spec exact.
- guard-proof: boots9, coat151, unknown glove, weapon0, unsupported P154 do not enter this bridge. No original source modified.
- private-check: G166 fit visually inspected at phases 0,1,4,7; private only.

Limits: this closes ONE real route, not all locomotion. Boots/coat are still unsupported by the preexisting authored North route, so this bridge never strips or replaces them. It falls through to ordinary selection for those combinations. It does not claim to combine arbitrary boots, alter profile/South, or add IDLE. Existing supported outfit routes remain unchanged. Weapon branches deliberately excluded until visible hand/weapon order is checked. For integration into another staged Native copy, pass layers.json in optional constructor and transplant only this stage.py North-specific changes; do not replace the whole module with this standalone copy.
