EDITABLE CHECKPOINT, NOT RUNTIME INSTALLATION
Fuzil113 female North/South: independent equipment catalog, 30 items per direction, original F151 appearance only. Browser loader exports MareStagedFuzil113NS.create(catalog, hashes). Keep original source selector guard in the existing integration. South rounding corrections are preserved.
No videos, previews or flattened full-character animation assets. PNG files are editable source layers. No repository integration or remote operation is performed by this archive. Provenance path labels were sanitized without changing image or motion data.
Run: python3 verify.py
