# Caminhada feminina Sul: dez botas independentes

Delta verificado para botas8/9/134/141/148/155/162/169/176/183. Apenas36camadas novas dos nove modelos;155existente preservada. Não contémPNG nem personagem composto: os hashes referenciam artes próprias já existentes no repositório.

Aplicar native-proposal.patch ao Native compatível e executar merge-boot-layers.cjs sobre o índice de roupas. Mesclagem idempotente, preserva demaisregistros. O carregador existente resolve os hashes dePNG. Não copiar outro corpo ou substituir a animação.

Proveniência: cada fonte frozen-v47-female-151-bootID-south-walk possui rest/poses/clock/frame/pivot/density e camadas não-botas iguais ao155. Os40ticks de155histórico coincidem com ascamadas155autorais através doframeToPhase. Transferência40→10estados semperda e semmovimento da sola.

Verificado:400ticks Native comuns, uma bota porvez comP147/G152;155RGBAexato40/40contraoriginal. Três rotas comremoção individual deoutra peça também funcionaram. Proofs incluídos. Sem resolverforçado.

Limites:WALKSUL somente. IDLE, outrasdireções, novasluvas, P154não cadastrada e customização decores não estão cobertos. Aberturas141/169mantidas. Nenhumaativação/push feita por este pacote.

Teste: node verify.cjs [caminho-do-index.json-ou-json.gz]
