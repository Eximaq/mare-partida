# Pistola114 feminina Sul: deltas inferiores editáveis

59PNGtransparentes próprios de equipamento, deduplicados porSHA256;10calças e10botas,8poses/30ticks24fps. NenhumPNGdepersonagem completo, vídeo oudiagnóstico incluído. Corpo, armas, peitoral, mãos, cabeça e fonteaprovada devemser fornecidos pela integraçãoexistente.

manifest.json contém apenas camadas de botas/calças com profundidades próprias. assets/ contém asartes independentes. apply-slot.cjs aplica uma peça porvez àbaseexata registrada por baseline-contract.json e mantém todasoutrascamadas/clock. Fonte diferente é rejeitada, não substituída. O carregador deve usar manifest.assets para resolver os novos hashes. Combinar doisdeltas deve preservar os dois slots; o helper propositalmente nãoafirma compatibilidadecom fontes modificadassemtestar.

Remates próprios: B134/B155/B162 bordas mínimas; B148aprovada intacta. P22/P147 tecido próprio cobre frestas laterais sem movercorpo, peitoral ou sola; P154aprovada intacta. Botas141/169mantêmaberturas; calçascurtas mantêmcorteintencional. Resíduo jáaceito da referência preservado, não pintado/apagado.

Verificado:80rendersNative debotas e80decalças; controlesB148/P154RGBAexatos8/8cada;20aplicações portáteis preservam outrascamadas eclock. Guardas decomprimento verificam nãoencurtamento da própriareferência, não todascombinações nem todas as caminhadas. NãoincluiNorte, luvas, corescustomizadas ouativaçãoemprodução.

Teste: node verify.cjs
