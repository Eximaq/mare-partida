from PIL import Image
import numpy as np,json,hashlib
from pathlib import Path
D=Path(__file__).parent; src=D.parent/'gloves-four-source-audit/glove180-screenLeft-r1.png'; art=Image.open(src).convert('RGBA');A=np.array(art).astype(float)
def data(a,donor=False):
 r,g,b,al=a.transpose(2,0,1);mask=al>20;gold=mask&(r>b*1.3)&(g>b*1.15)&(r>75)
 if donor:
  yy=np.where(gold)[0];gold&=np.indices(gold.shape)[0]<yy.min()+10
 y,x=np.where(gold); wrist=np.array([x.mean(),y.mean()]);y,x=np.where(mask&~gold);q=np.stack([x,y],1);v=q.mean(0)-wrist;v/=np.linalg.norm(v);u=np.array([v[1],-v[0]]);proj=(q-wrist)@v;wide=(q-wrist)@u
 return wrist,np.stack([u,v],1),np.percentile(proj,98),np.percentile(wide,98)-np.percentile(wide,2)
sw,sbasis,sl,ss=data(A,True);rows=[];layers={d:[] for d in ['east','west']};(D/'assets').mkdir(exist_ok=True)
for d in layers:
 for side in ['near','far']:
  refs=[]
  for f in range(8):
   target=np.array(Image.open(D/'input'/f'{d}-{side}-{f}.png').convert('RGBA')).astype(float);tw,tbasis,tl,ts=data(target);scale=[min(1.5,max(.65,ts/ss)),min(1.5,max(.65,tl/sl))];M=tbasis@np.diag(scale)@sbasis.T;inv=np.linalg.inv(M);offset=sw-inv@tw
   out=art.transform((512,512),Image.Transform.AFFINE,tuple([*inv[0],offset[0],*inv[1],offset[1]]),Image.Resampling.BICUBIC);file=D/f'g180-{d}-{side}-{f}.png';out.save(file);sha=hashlib.sha256(file.read_bytes()).hexdigest();(D/'assets'/f'{sha}.png').write_bytes(file.read_bytes());refs.extend([sha]*5);rows.append({'direction':d,'side':side,'phase':f,'scale':scale,'sourceWrist':sw.tolist(),'targetWrist':tw.tolist(),'matrix':M.tolist(),'sha':sha})
  layers[d].append({'id':f'own-g180-profile-{side}','slot':'foreground','depth':50,'source':refs[0],'frames':refs,'binding':{'kind':'fixed'}})
(D/'layers.json').write_text(json.dumps(layers));(D/'fit.json').write_text(json.dumps({'source':str(src),'sourceSHA':hashlib.sha256(src.read_bytes()).hexdigest(),'rows':rows},indent=2))
