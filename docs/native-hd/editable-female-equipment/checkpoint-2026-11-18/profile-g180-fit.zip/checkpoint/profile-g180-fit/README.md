# Own G180 material fitted to real walking profile hands

Separate local candidate, no repo/PR/media edits. The preceding nine safe items are unchanged (18 directional records checked by export.cjs). merged-layers.json adds only G180.

Own source: gloves-four-source-audit/glove180-screenLeft-r1.png, SHA and all affine parameters in fit.json. Existing correctly registered G166 wrist/cuff and palm-to-finger axis are used ONLY as geometric landmarks; zero G166 RGB or alpha is transferred. Source G180 RGBA is rigidly rotated and modestly scaled in its local transverse/longitudinal axes (0.682–1.263), then translated by cuff landmark. No skin/body pixels copied, no hand replaced, no alpha trimming, painting or invented hand anatomy. E/W registered separately against their own existing hand records; no assumed mirror.

32 own PNGs =2directions×2hands×8phases. Current authored12/40 phase clock selects these original phase references. Existing profile bridge draws before weapon/foreground occlusion, preserving P21 and original head/skin/eyes, weapon state and motion. Images are independent transparent equipment, not combined body exports.

Private ownfit.png inspected real Native sword0 E/W phase0/4/7 (also1): wrist follows forearm and fingers no longer protrude beside a vertically oriented glove. The donor's original dark/gold ornamentation and alpha are retained. This is a technically/visually checked fitting candidate, not a new claim of user approval.

For integration pass merged-layers.json to the existing profileGloveLayers hook, and resolve assets/<sha>.png from this folder first when URL basename is present. Do not replace the unified Native module with this standalone stage. test.cjs tests ONLY added G180 through ordinary selector/prepare, retaining the earlier nine-item proof unchanged.

Completed proof.json: 8 ordinary routes,1280 actual Native draws including baselines/unequip; G180×E/W×(P21+weapon0, P21+weapon5, P21+weapon17, P21+dark/bob/blonde without weapon). All defaults/removal RGBA exact original, every change within own transformed glove alpha, source body/pack/spec exact. No forced resolver, no per-color source PNGs. Other unsupported slots remain outside the profile bridge rather than discarded.
