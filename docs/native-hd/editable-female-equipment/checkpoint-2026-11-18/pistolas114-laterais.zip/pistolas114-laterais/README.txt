EDITABLE CHECKPOINT, NOT RUNTIME INSTALLATION
Pistolas114 female West/East: approved own West component order, exact horizontal East mirror, 30 equipment choices per direction. Node adapter staged only, F151/original appearance; unsupported/absent items held.
No videos, previews or flattened full-character animation assets. PNG files are editable source layers. No repository integration or remote operation is performed by this archive. Provenance path labels were sanitized without changing image or motion data.
Run: python3 verify.py
