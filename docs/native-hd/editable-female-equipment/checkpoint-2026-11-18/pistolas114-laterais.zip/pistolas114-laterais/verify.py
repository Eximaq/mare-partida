import pathlib,json,hashlib
p=pathlib.Path(__file__).resolve().parent
m=json.loads((p/'SHA256.json').read_text())
for f,h in m.items():
 b=(p/f).read_bytes();assert hashlib.sha256(b).hexdigest()==h,f
 if f.startswith('assets/') and f.endswith('.png'):assert pathlib.Path(f).stem==h,f
print('PASS',len(m),'files, all layer content hashes exact')
