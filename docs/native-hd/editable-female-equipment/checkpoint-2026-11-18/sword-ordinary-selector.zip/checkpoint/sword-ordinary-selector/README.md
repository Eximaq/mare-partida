# Sword ordinary-selector staging, isolated from repo/root stage

Reads the existing source guards and independent slots in `sword-fio-e-equipamentos/all-directions.cjs`. This stage does not refit art or introduce new equipment sprites. `stage.py` copies the current Native module into this directory and injects one optional sword-only selector hook. The root's stage-native-hook.py and every repository file remain untouched.

API: `require('./create.cjs').create()` returns a normal Native API with the isolated hook and asset resolver. Calling ordinary `select(player,options)` and `prepareConfiguration([{player,options}])` reaches the equipment adapter without a forced resolver/source. No caller-side visual substitution is needed.

Critical source constraints:
- Female, weapon0, coat151, exact captured appearance `{gender:'feminino',skinColor:'original',hairStyle:'hair-cropped',hairColor:'blonde',eyeColor:'amber'}`.
- Coat151 must remain in the base source request; stripping down to weapon-only as in a generic hook does not meet these exact source guards.
- Requested pants/legs, boots and gloves are independently mapped. A missing item retains only that slot's legacy/base layer, without disabling known slots. Other equipment, coat, source or appearance never gets silently removed or coerced to this look.
- Other sword IDs are not claimed supported by this stage. Their own weapon-state signatures differ from these existing immutable locks; they keep the original route pending a separately proven family bridge.

Lateral weapon matrices come solely from `espada-fio-baixo-editavel/patch.cjs`; the hand grip and authored shaft tip stay exact with the cutting edge down. NORTH/SOUTH weapon states never change. The approved lateral orientation remains down even when all three equipment slots are removed; body/coat layers return exactly to the base. A separate re-entry flag prevents the base-source lookup recursively invoking this same selector extension.

Tests:
- proof.json:120 single-slot scopes (30 items ×4directions),960 ordinary Native frames, no prepare resolve override. Exact original pose fields and lateral edge matrices checked per phase.
- structural-proof.json:120 checks proving every non-owned body/clothing layer and appearance field stays exact. Only the corresponding original shorts/hands may be replaced according to existing slot ownership.
- unequip-proof.json:32 ordinary Native frames; body/coat exact, N/S weapon unchanged, E/W cutting edge remains down after unequip.
- Wrong skin, coat, weapon, head remain outside the hook; unknown glove with known pants retains pants and reports glove fallback.
- stage-proof.json pins the original Native SHA; main test verifies repository file unchanged.

No new artistic review, user media, repo edit, PR or runtime activation. This is a separate ordinary-selector integration proposal with existing supported appearance constraints, not a global completion claim.
