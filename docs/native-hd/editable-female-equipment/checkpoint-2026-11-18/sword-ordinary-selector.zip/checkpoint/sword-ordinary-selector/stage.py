from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent;R=P.parent.parent/'repo';s=(R/'player-rework-native-hd.js').read_text();before=hashlib.sha256(s.encode()).hexdigest();needle='loadImage=null,makeCanvas=';assert s.count(needle)==1;s=s.replace(needle,'loadImage=null,swordSlotAdapter=null,makeCanvas=',1)
needle='  const independentPants=!player.__reworkSubset&&outfitRegistry?.resolveIndependentPants?.(';assert s.count(needle)==1
s=s.replace(needle,'''  // Isolated sword-only hook: retain exact requested appearance and coat in the source selection.
  if(swordSlotAdapter&&allowApprovedAppearance&&!player.__reworkSubset&&!player.__swordSlotSource&&!o.weaponless&&o.action==='attack-sword'&&canonical(a.body)==='female'){
   const value=v=>v?.def??v,keys=Object.keys(equipment),names={pants:'pants',legs:'pants',boots:'boots',gloves:'gloves'};
   const selection=Object.fromEntries(keys.filter(k=>names[k]).map(k=>[names[k],value(equipment[k])]));
   if(value(equipment.coat)===151&&value(equipment.weapon)===0&&!(equipment.pants!=null&&equipment.legs!=null)&&keys.every(k=>['weapon','coat','pants','legs','boots','gloves'].includes(k))){
    const original=selectBase({...player,__swordSlotSource:true,equipment:{weapon:equipment.weapon,coat:equipment.coat}},o,allowApprovedAppearance,onlyApprovedAppearance);
    if(original){const result=swordSlotAdapter.apply(original,o.direction,player,selection);if(result.applied.length||(['east','west'].includes(o.direction)&&result.source!==original)){result.source.localSwordSlotResult={applied:result.applied,fallback:result.fallback};return result.source;}}
   }
  }
''' +needle,1)
(P/'native-staged.cjs').write_text(s);(P/'stage-proof.json').write_text(json.dumps({'originalNativeSHA256':before,'repoEdited':False,'basedOn':'feminino-pre-pr-0307/stage-native-hook.py approach; source coat and actual requested appearance retained'},indent=2))
