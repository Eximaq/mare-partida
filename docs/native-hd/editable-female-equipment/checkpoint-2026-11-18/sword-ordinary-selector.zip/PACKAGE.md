# Local checkpoint source package

Not runtime activation, not a claim of new user visual approval. Extract preserving checkpoint/ directory names alongside the existing repo/. Includes editable code, layer contracts, SHA evidence and tests. No composite frames, video, or diagnostic image boards. G180 assets/input are transparent own garment sources and geometry guides, not body render outputs.

Dependencies intentionally not duplicated:
- repo existing Native registries/assets
- checkpoint/sword-fio-e-equipamentos/all-directions.cjs and transitive existing sword checkpoints

Run Node tests with the project canvas dependency available (NODE_PATH=deps/node_modules). Native staging files are isolated copies, not changes to repo. Root owns integration and commit.
