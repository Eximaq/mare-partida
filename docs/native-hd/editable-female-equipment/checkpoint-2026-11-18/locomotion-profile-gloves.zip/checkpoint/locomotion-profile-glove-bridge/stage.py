from pathlib import Path
import json,hashlib
D=Path(__file__).parent;R=D.parent.parent/'repo';text=(R/'player-rework-native-hd.js').read_text();a=text.index(' function resolveProfileLayers(');b=text.index(' function resolveNorthLayers(',a);part=text[a:b]
part=part.replace("['weapon','legs','pants'].includes(key)","['weapon','legs','pants','gloves'].includes(key)")
part=part.replace('const d=s.directions?.[dir],clock=',"const gloveId=equipment.gloves==null?null:Number(equipment.gloves.def??equipment.gloves),glove=gloveId==null?null:profileGloveLayers?.[dir]?.[gloveId];if(gloveId!=null&&!glove)return null;\n  const d=s.directions?.[dir],clock=")
part=part.replace("':'+body.id,hdKind", "':'+body.id+':glove:'+gloveId,hdKind")
part=part.replace('profileLayers:{spec:s,body,pants}', 'profileLayers:{spec:s,body,pants,glove}')
part=part.replace('...femaleRegistry.requiredFiles(body,{frame:phase}),',"...femaleRegistry.requiredFiles(body,{frame:phase}),...(r.profileLayers.glove||[]).map(l=>'tools/rework-modular-outfits-hd/assets/'+l.frames[phase*5]+'.png'),")
part=part.replace('const pad=body.paddingPhysical||0,W=',"for(const l of r.profileLayers.glove||[])ctx.drawImage(source('tools/rework-modular-outfits-hd/assets/'+l.frames[phase*5]+'.png'),0,0);\n  const pad=body.paddingPhysical||0,W=")
text=text[:a]+part+text[b:];text=text.replace('function create({','function create({profileGloveLayers,',1);(D/'native-staged.cjs').write_text(text)
cat=json.loads((D.parent/'idle-walk-gloves-local/catalog.json').read_text()); rows={d:{str(x['item']):x['gloveLayers'] for x in cat if x['action']=='walk' and x['direction']==d and not x['derived']} for d in ['east','west']}
(D/'layers.json').write_text(json.dumps(rows));(D/'stage-proof.json').write_text(json.dumps({'originalSHA256':hashlib.sha256((R/'player-rework-native-hd.js').read_bytes()).hexdigest(),'ids':{d:list(rows[d]) for d in rows}},indent=2))
