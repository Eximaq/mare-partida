# WALK profile E/W: independent own glove bridge

Local only. No repo/PR edits or media sent.

`create.cjs::create()` exposes Native directly. `stage.py` adds an optional `profileGloveLayers` constructor map and patches only the real authored-profile selector/files/compositor. It does not use a forced prepare resolver or a raw-pack fallback.

9 own IDs per direction: 25,26,131,138,145,152,159,166,173. Their saved eight hand states are selected using the existing 12-pose/40-tick source phaseMap. Source art remains byte-exact; no new images or per-color variants. Each side uses its existing own directional PNGs, not an extra mirror.

Gloves are drawn on the already-authored body before the existing weapon operation and foreground-mask restoration, then existing head operations. Original P21 remains unchanged; existing weapon0/5/17 matrices/parts and source appearance stay untouched. Unknown slots remain on the normal route, never stripped to force this renderer.

Proof: `proof.json`:72 actual ordinary routes,3840 Native draws including baseline/removal. 9 IDs ×2 sides ×(P21/weapon0, P21/weapon5, P21/weapon17, P21/dark-bob-blonde no weapon). All baseline and unequip outputs byte-exact original RGBA; all changed pixels inside the selected own glove alpha. Original pack, body, spec identical. No forced resolver. `geometry-proof.json`: current real skin and donor near-hand contact pixels match exactly in20/24 authored poses; remaining4 differ by only1–2 boundary pixels (no displacement), recorded rather than hidden. Visual G166/P21 and sword0 checked in both directions at four poses each. `guard-proof.json`: unsupported boots, coat, ID180, unknown ID, P154 do not enter this bridge. Repo SHA unchanged.

Scope excludes arbitrary coats/boots: the released profile renderer itself does not accept those slots. Existing authored P21 and current supported weapon are preserved, not replaced. No idle route added.

G180 separate HOLD: `g180-check.cjs` and private `g180-candidate.png` render the existing North-derived candidate against these exact poses, not a generic audit. Its vertical North hand/cuff leaves the native angled hand exposed beside the glove in forward arm phases; e.g. E phase4 (tick20) and matching W have horizontal fingertips alongside vertical glove material. Copying that candidate would falsely call it fitted. Own `gloves-four-source-audit/glove180-screenLeft-r1.png` is a narrow North-facing clenched-hand donor, not the profile pose. Minimal remaining work is per-hand wrist→palm/fingertip registration and deformation of that own G180 material to the real angled hand footprint, preserving cuff and own alpha; translation alone cannot align both wrist and tips. It was not promoted or mixed into the 9-ID proof.

To integrate: transplant only stage.py profile-region changes into the unified staged Native and pass layers.json as `profileGloveLayers`; do not replace the whole unified module with this standalone copy.
