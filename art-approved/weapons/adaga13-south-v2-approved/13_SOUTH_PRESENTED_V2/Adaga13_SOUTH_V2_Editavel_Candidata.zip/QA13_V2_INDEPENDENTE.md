# QA independente 13 v2: parecer corrigido

Parecer: LIBERADA PARA PRÉVIA CANDIDATA, não aprovação final. A aprovação anterior da base 12 não foi confirmada.

## Errata da primeira inspeção
Retiro a rejeição anterior por suposto terceiro braço. Foi erro de visualização/inspeção do PNG RGBA bruto: RGB residual de pixels inteiramente transparentes apareceu na visualização. Não há terceiro braço na composição correta source-over. No quadro 1, os pixels suspeitos (380,355), (380,360), (379,370), (385,345) e (370,360) têm alpha 0. Eles não devem aparecer em um renderizador que respeita alpha. Não é defeito corporal visível herdado da base, como eu havia afirmado incorretamente.

Refiz a inspeção individual dos 9 quadros a 640×640 após composição source-over sobre fundo opaco RGB (100,110,120). As imagens de prova estão em front-adapt-audit/qa13-source-over/0.png até 8.png. Somente essas provas de QA foram produzidas; nenhuma arte original foi modificada.

## Resultado visual corrigido
- Dois braços em todos os 9 quadros; quadro lift/índice 1 não apresenta membro extra.
- Não observei arma sobre o rosto nem corte na borda do canvas.
- Cabos e mãos têm contato visual plausível. O interior oculto da pegada não é certificável pela composição.
- A arma secundária passa diante da parte alta do torso/ombro, sem encobrir a face.
- Alguns contornos dos punhos são angulares, mas não identifiquei um defeito novo inequívoco que impeça mostrar a candidata.

## Verificação técnica independente
- 9/9 camadas body pixel-exatas às camadas body-visible da base 12.
- 9/9 camadas foreground pixel-exatas às camadas foreground da base 12.
- 0 pixels alterados fora da união alpha do equipamento antigo/novo em cada estado.
- Alpha total nas 4 bordas = 0 em todos os 9 quadros: sem cortes no limite do canvas.
- SHA256 da fonte 13: 66d4e625030427fcefa464062e114b8b22bf3896e1181673e7ae43f6d5d990e2.
- Ambos os MP4 decodificados integralmente, com 16 quadros; sequência inferida por diferença RGB mínima exatamente [0,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8]. Erro médio RGB máximo 0.9274 no normal e 0.8035 no lento, compatível com compressão.

## Escopo e limites
Não assisti a playback contínuo nem testei em runtime. Decodificação e revisão estática comprovam conteúdo e ordem, não certificam fluidez perceptiva. A decisão de prévia não equivale a aprovação final do usuário, especialmente porque a aprovação da base 12 não foi confirmada. Não alterei arte, timing, corpo, máscaras ou fonte 13. Não executei correção de lâmina nem outra operação recusada.

## Rastreabilidade
Candidata: front-adapt-audit/pilot13-v2-equipment-registration/.
Base comparada: front-adapt-audit/more/Adagas12_Ciclo_Pareado_Completo_v1/layers/.
ROI do falso positivo anterior: x343–399, y245–380; pixels suspeitos na mão de repouso eram transparentes. Esta ROI serve apenas ao registro da errata.
