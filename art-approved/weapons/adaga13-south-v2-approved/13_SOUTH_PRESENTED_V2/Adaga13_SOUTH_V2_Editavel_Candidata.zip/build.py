from pathlib import Path
from PIL import Image,ImageDraw
import json,math,hashlib,shutil
import numpy as np
R=Path(__file__).parent;B=R/'base12';S=R/'source13-original.png';O=R/'pilot13-v2-equipment-registration';O.mkdir(exist_ok=True)
s=Image.open(S).convert('RGBA');shutil.copy2(S,O/'source13-original.png');es=json.load(open(B/'sources/active-contract.json'))['entries'];regs={str(e['phase']):[(x['grip'],x['angle']) for x in e['registrations']] for e in es}
regs['0']=[([255,360],110),([378,360],70)];regs['1'][0]=([250,360],110);regs['7']=[([254,360],110),([379,360],70)];regs['lift']=[([255,360],110),([370,329],-35)]
for k in ['1','2','3','4','5']: regs[k][1]=(regs[k][1][0],-145)
states=['0','lift','1','2','3','4','5','6','7'];qa=[];sheet=Image.new('RGBA',(1280,1440),(100,110,120,255))
for i,state in enumerate(states):
 b=Image.open(B/f'layers/{i}-body-visible.png').convert('RGBA');h=Image.open(B/f'layers/{i}-foreground.png').convert('RGBA');g=Image.new('RGBA',b.size)
 for p,ang in regs[state]:
  a=math.radians(ang+45);M=np.array([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]])*.265;iv=np.linalg.inv(M);off=np.array([62,245])-iv@np.array(p)
  one=s.transform(b.size,Image.Transform.AFFINE,(*iv[0],off[0],*iv[1],off[1]),Image.Resampling.BICUBIC);g.alpha_composite(one)
 oldg=Image.open(B/f'layers/{i}-equipment.png').convert('RGBA');old=Image.alpha_composite(Image.alpha_composite(b,oldg),h);assert old.tobytes()==Image.open(B/f'layers/{i}-composite.png').convert('RGBA').tobytes()
 c=Image.alpha_composite(Image.alpha_composite(b,g),h);diff=np.any(np.array(c)!=np.array(old),axis=2);support=(np.array(g)[:,:,3]>0)|(np.array(oldg)[:,:,3]>0);assert not np.any(diff&~support)
 for n,im in [('body',b),('foreground',h),('equipment',g),('composite',c)]:im.save(O/f'{i}-{n}.png')
 qa.append({'state':state,'outside_equipment_changes':0,'body_unchanged':True,'foreground_unchanged':True,'old_recompose_exact':True,'placements':regs[state]})
 sheet.alpha_composite(c.resize((426,426)),((i%3)*426,(i//3)*480+30));ImageDraw.Draw(sheet).text(((i%3)*426+10,(i//3)*480+5),state,fill='white')
sheet.convert('RGB').save(O/'ALL9.png');(O/'QA.json').write_text(json.dumps({'status':'diagnostic ONLY; base12 candidate not proven user-approved; no direction completed','source13_sha256':hashlib.sha256(S.read_bytes()).hexdigest(),'source13_unchanged':True,'denied_source_used':False,'blade_outline_edit':False,'states':qa},indent=2))
