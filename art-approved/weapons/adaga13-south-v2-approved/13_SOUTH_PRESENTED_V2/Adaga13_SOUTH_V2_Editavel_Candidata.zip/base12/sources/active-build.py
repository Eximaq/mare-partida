from PIL import Image,ImageDraw
from pathlib import Path
import numpy as np,math,json,hashlib
D=Path(__file__).parent;P=Path('114-recovery/recovered-pilots/daggers12-visible-contact-pilot-v1');s=Image.open('12-recovery/weapon-own-hd-v1/source.png').convert('RGBA');es=json.load(open(P/'VISIBLE_CONTACT_CONTRACT.json'))['entries'];sheet=Image.new('RGBA',(1280,760),(101,113,128,255));records=[]
for i,e in enumerate(es):
 b=Image.open(P/'original'/f'{i:02}.png').convert('RGBA');g=Image.new('RGBA',b.size);owner=Image.new('RGBA',b.size);trip=Image.new('RGBA',(720,480),(101,113,128,255));rs=[]
 for side,p in enumerate(e['visibleHandCenters']):
  p=list(p);ang=e['bladeAngleDegrees'][side]
  if side==0 and i in [2,3,4,5,6]: ang={2:200,3:210,4:180,5:180,6:160}[i]
  if side==1 and i in range(1,6): p=[p[0]+8,p[1]-2];ang=-100
  if side==1 and i==6:ang=20;p=[p[0]+4,p[1]+4]
  a=math.radians(ang+132);A=np.array([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]])*.10;iv=np.linalg.inv(A);off=np.array([740,780])-iv@p
  one=s.transform((1280,1280),Image.Transform.AFFINE,(iv[0,0]/2,iv[0,1]/2,off[0],iv[1,0]/2,iv[1,1]/2,off[1]),Image.Resampling.BICUBIC).resize(b.size,Image.Resampling.LANCZOS);g=Image.alpha_composite(g,one)
  x,y=p;m=Image.new('L',b.size);ImageDraw.Draw(m).polygon([(x-14,y-10),(x-5,y-18),(x+6,y-18),(x+15,y-10),(x+15,y+15),(x+3,y+18),(x-11,y+9)],fill=255);h=b.copy();h.putalpha(Image.fromarray(np.minimum(np.array(m),np.array(b.getchannel('A')))));owner=Image.alpha_composite(owner,h);rs.append({'side':side,'grip':p,'angle':ang})
 c=Image.alpha_composite(Image.alpha_composite(b,g),owner)
 for n,im in [('body',b),('equipment',g),('owner',owner),('composite',c)]:im.save(D/f'{n}-{i}.png')
 for side,p in enumerate(e['visibleHandCenters']):
  box=(p[0]-40,p[1]-45,p[0]+40,p[1]+35)
  for k,im in enumerate([b,g,c]):trip.alpha_composite(im.crop(box).resize((240,240),Image.Resampling.NEAREST),(k*240,side*240))
 trip.convert('RGB').save(D/f'TRIPLE{i}.png');sheet.alpha_composite(c.resize((320,320)),(i%4*320,i//4*380+25));ImageDraw.Draw(sheet).text((i%4*320+8,i//4*380+5),str(i),fill='white');records.append({'phase':i,'registrations':rs})
sheet.convert('RGB').save(D/'ALL8.png');json.dump({'status':'Diagnostic only, provisional foreground polygons are not certified grip; rest open hands not selected','sourceGrip':[740,780],'sourceAxis':-132,'scale':.10,'entries':records,'sourceSHA256':hashlib.sha256(Path('12-recovery/weapon-own-hd-v1/source.png').read_bytes()).hexdigest()},open(D/'CONTRACT.json','w'),indent=2)
