from PIL import Image,ImageDraw
from pathlib import Path
import numpy as np,math,json,hashlib
D=Path(__file__).parent;R=Path('71-recovery/rest-family-fit-v1');A=Path('12-recovery/paired-registration-v1');s=Image.open('12-recovery/weapon-own-hd-v1/source.png').convert('RGBA');sheet=Image.new('RGBA',(960,350),(100,110,120,255));rows=[]
for k,i in enumerate([0,1,7]):
 b=Image.open(R/f'{i}-body-visible.png').convert('RGBA');h=Image.open(R/f'{i}-foreground.png').convert('RGBA');g=Image.new('RGBA',b.size);rows.append({'phase':i,'bodySHA256':hashlib.sha256((R/f'{i}-body-visible.png').read_bytes()).hexdigest(),'visibleHandsSHA256':hashlib.sha256((R/f'{i}-foreground.png').read_bytes()).hexdigest()})
 for side in [0,1]:
  if i==1 and side==1:
   ar=np.array(Image.open(A/'equipment-1.png'));ar[:,:285,3]=0;g.alpha_composite(Image.fromarray(ar));continue
  dx=(-5 if i==1 else (-1 if i==7 else 0)) if side==0 else (1 if i==7 else 0);p=[255+dx,360] if side==0 else [378+dx,360];ang=110 if side==0 else 70
  a=math.radians(ang+132);M=np.array([[math.cos(a),-math.sin(a)],[math.sin(a),math.cos(a)]])*.10;iv=np.linalg.inv(M);off=np.array([790,830])-iv@p
  one=s.transform((1280,1280),Image.Transform.AFFINE,(iv[0,0]/2,iv[0,1]/2,off[0],iv[1,0]/2,iv[1,1]/2,off[1]),Image.Resampling.BICUBIC).resize(b.size,Image.Resampling.LANCZOS);g.alpha_composite(one)
 oldh=h;h=Image.new('RGBA',b.size);newh=Image.open('71-72-upper-grip-revision/hand-fit-v2/foreground.png').convert('RGBA')
 for side in [0,1]:
  if i==1 and side==1:
   ar=np.array(oldh);ar[:,:285,3]=0;h.alpha_composite(Image.fromarray(ar));continue
  ar=np.array(newh);ar[:,320 if side==0 else 0:640 if side==0 else 320,3]=0;dx=(-5 if i==1 else -1 if i==7 else 0) if side==0 else (1 if i==7 else 0);h.alpha_composite(Image.fromarray(ar).transform((640,640),Image.Transform.AFFINE,(1,0,-dx,0,1,0),Image.Resampling.NEAREST))
 c=Image.alpha_composite(Image.alpha_composite(b,g),h)
 for n,im in [('body-visible',b),('equipment',g),('foreground',h),('composite',c)]:im.save(D/f'{i}-{n}.png')
 bg=Image.new('RGBA',c.size,(100,110,120,255));bg.alpha_composite(c);bg.convert('RGB').save(D/f'{i}-WHOLE.png');bg.crop((225,325,410,395)).resize((1110,420),Image.Resampling.NEAREST).convert('RGB').save(D/f'{i}-DETAIL.png');sheet.alpha_composite(c.resize((320,320)),(k*320,20))

for r in rows:
 r['historicalSharedHandSHA256']=r.pop('visibleHandsSHA256');r['actualForegroundSHA256']=hashlib.sha256((D/f"{r['phase']}-foreground.png").read_bytes()).hexdigest()
json.dump({'status':'diagnostic own 12 fitting on explicitly shared visible closed-hand authorship; not original 12 hands, no approval inherited','bodySource':str(R),'visibleHandSource':'71-72-upper-grip-revision/hand-fit-v2/foreground.png','handScope':'Common closed visible hand surfaces, independently fitted to12 downward grip; no upper-direction request transferred','weaponSource':'12-recovery/weapon-own-hd-v1/source.png','sourceGrip':[790,830],'scale':.10,'entries':rows},open(D/'CONTRACT.json','w'),indent=2);sheet.convert('RGB').save(D/'THREE_STATES.png')
