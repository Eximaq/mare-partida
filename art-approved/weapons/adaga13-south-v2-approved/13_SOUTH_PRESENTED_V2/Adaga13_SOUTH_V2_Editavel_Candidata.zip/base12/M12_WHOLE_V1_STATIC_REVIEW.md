# M12 — candidata integral v1, revisão independente estática

Autoridade:12-recovery/whole-cycle-diagnostic-v1/ALL9.png e MANIFEST.json. Fonte própria weapon-own-hd-v1, ativos paired-registration-v1, repousos rest-family-fit-v2 e lift-common-visible-v2. Catálogo/fonte nativa previamente auditados em M12_INITIAL_AUDIT.md; parent informou ao autor que não recuperou autoridade aprovada adicional.

Vistos IDENTITY, triplas ativos2–6, detalhes0/1/7 e lift, integral nove estados, ENDS6 e ENDS_SECONDARY0_7. Parecer favorável à candidata visual estática integral, não aprovação do usuário.

Identidade própria preserva lâmina cyan curta, guarda transversal dourada larga, cabo de couro e pomo compacto. Facetamento é interpretação autoral; não importa desenho ou escala74. Guarda larga não é defeito automático e não exige estreitamento para caber no punho.

As mãos autorais contínuas compartilhadas são declaradas e registradas sobre os corpos próprios; não herdam aprovação de outro item. Não vejo concavidade vazia ou degrau amplo novo nas junções0/1/7. Direções baixas próprias12 foram mantidas, sem extrapolar pedido superior71/72. No lift, conexão externa ao punho e trajetória intermediária são legíveis.

Principal6: suspeita inicial do metal proximal foi confrontada com ENDS6; centro do pomo cai na convexidade lateral da mão abaixo do estreitamento do punho, não há conflito inequívoco com antebraço. Secundárias0/7: ENDS_SECONDARY0_7 situa pomo na borda superior/lateral do polegar, também abaixo do antebraço estreito. Couro livre abaixo da mão resulta da pegada proximal no próprio cabo; não é troca de comprimento da fonte. Nenhum pedido de ampliar owner ou ocultar extremos foi feito.

Ativos2–5 mantêm relação plausível da guarda com seção visível; parte dos cabos/pomos permanece oculta, sobretudo secundárias. Isso limita a verificação, não certifica anatomia interna. Na integral9 não identifiquei troca de família/escala ou desconexão externa nova que exija outro registro. Retorno rápido e distribuição de tempos ainda exigem verificação em movimento.

Limites: sem playback contínuo assistido, certificação de fluidez, rig/interior oculto, VFX ou integração runtime. Nenhuma arte editada por esta QA. Preservar manifesto/fontes efetivos e provas técnicas no backup do autor.
