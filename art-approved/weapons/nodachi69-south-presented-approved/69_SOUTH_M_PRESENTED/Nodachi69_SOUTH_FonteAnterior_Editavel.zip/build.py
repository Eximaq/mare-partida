from pathlib import Path
from PIL import Image,ImageDraw
import json,numpy as np,math,hashlib,shutil
P=Path(__file__).parent;B=P.parent/'south1-68-audit/editable-package/base';r=json.load(open(P.parent/'south1-68-audit/equipment-only-candidates/RECIPE.json'));w=Image.open(P/'source69.png').convert('RGBA');qa=[]
for d in ['base','frames','gear','video']:(P/d).mkdir(exist_ok=True)
board=Image.new('RGB',(1344,1344),'#8899aa');zo=Image.new('RGB',(1440,160),'#8899aa')
for k,(g,a) in enumerate(zip(r['grips'],r['angles'])):
 x,y=np.array(g)+128;t=math.radians(a-20);co=math.cos(t);si=math.sin(t);coeff=(co,si,385-co*x-si*y,-si,co,420+si*x-co*y)
 eq=w.transform((896,896),Image.Transform.AFFINE,coeff,Image.Resampling.BICUBIC)
 layers=[]
 for suffix in ['body-visible','foreground']:
  b=Image.open(B/f'{k}-{suffix}.png').convert('RGBA');o=Image.new('RGBA',(896,896));o.alpha_composite(b,(128,128));o.save(P/'base'/f'{k}-{suffix}.png');layers.append(o)
 b,f=layers;im=Image.alpha_composite(Image.alpha_composite(b,eq),f);base=Image.alpha_composite(b,f);mask=np.array(eq)[:,:,3]>0
 qa.append({'pose':k,'outsideEquipmentExact':np.array_equal(np.array(im)[~mask],np.array(base)[~mask]),'clipping':bool(mask[0].any()or mask[-1].any()or mask[:,0].any()or mask[:,-1].any()),'bodyForegroundUnchanged':True})
 im.save(P/'frames'/f'{k}.png');eq.save(P/'gear'/f'{k}.png');small=im.resize((448,448));board.paste(small,((k%3)*448,(k//3)*448),small);ImageDraw.Draw(board).text(((k%3)*448+5,(k//3)*448+5),f'69 SOUTH {k}',fill='black')
 cr=im.crop((x-40,y-40,x+40,y+40)).resize((160,160));zo.paste(cr,(k*160,0),cr);ImageDraw.Draw(zo).text((k*160,0),str(k),fill='black')
 view=Image.new('RGB',(896,936),'#8899aa');view.paste(im,(0,40),im);ImageDraw.Draw(view).text((20,12),f'Nodachi69 SOUTH | fonte anterior intacta | pose{k}',fill='black');view.save(P/'video'/f'{k}.png')
board.save(P/'ALL9.png');zo.save(P/'GRIPS9.png');json.dump(qa,open(P/'QA.json','w'),indent=2)
r.update({'item':69,'source69sha256':hashlib.sha256((P/'source69.png').read_bytes()).hexdigest(),'source69angle':20,'source69grip':[385,420],'source69scale':1,'padding':128,'newArt':False,'newMotion':False,'deniedHDSourceUsed':False,'body':'approved68 SOUTH body and foreground identical to67','status':'candidate pending visual review'});json.dump(r,open(P/'RECIPE.json','w'),indent=2)
