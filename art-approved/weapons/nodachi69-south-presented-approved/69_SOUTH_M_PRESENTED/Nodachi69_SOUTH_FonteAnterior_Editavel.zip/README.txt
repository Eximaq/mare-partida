Nodachi69 SOUTH: reutilização integral da mesma fonte69 anterior aprovada emE/W, sem redesenho ou edição de detalhes.
Corpo+foreground do68SOUTH recém aprovado preservados; canvas896, padding128 constante. Arma: rotação rígida, escala1constante. Nove poses, relógio original16ticks/24fps.
Sem novos movimentos, sem integração, sem aprovação do usuário. Prévia normal6repetições; lenta2repetições a8fps.
Não usa HD posterior recusado, não executa a correção de identidade negada.
Reproduzir composição: python RESTORE.py.
