from PIL import Image
from pathlib import Path
import numpy as np
p=Path(__file__).parent
for i in range(9):
 b=Image.open(p/f'base/{i}-body-visible.png');f=Image.open(p/f'base/{i}-foreground.png');g=Image.open(p/f'gear/{i}.png');r=Image.alpha_composite(Image.alpha_composite(b,g),f);assert np.array_equal(np.array(r),np.array(Image.open(p/f'frames/{i}.png')))
print('9states RGBA exact')
