from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json,base64,io,math
P=Path(__file__).parent;V=Path('refazer69-north-v5');qa=[]
for d in ['base','gear','frames','video']:(P/d).mkdir(exist_ok=True)
pack=json.load(open('south1-68-audit/Ataques_M_sword_Historicos_Retorno_Diagnostico_v1/packs/sword-north-modular8-historical-v2.json'));layer=next(l for l in pack['pack']['directions']['north']['layers'] if l['id']=='forearm-hand-near')
sheet=Image.new('RGB',(1280,640),'#778899')
for k in range(8):
 original=Image.open(V/'base'/f'{k}.png').convert('RGBA');b=original.copy();eq=Image.open(V/'gear'/f'{k}.png').convert('RGBA')
 if k in [0,7]:
  src=Image.open(io.BytesIO(base64.b64decode(pack['images'][layer['frames'][k]].split(',')[1]))).convert('RGBA').transpose(Image.Transpose.FLIP_LEFT_RIGHT)
  sa=np.array(src);yy,xx=np.mgrid[:640,:640];allowed=(yy>=334)&(yy<385)&(xx>355)&(xx<410);sa[~allowed]=0
  # Keep wrist anchor fixed; smoothly tilt only existing distal hand12deg inward.
  theta=np.deg2rad(8)*np.clip((yy-334)/18,0,1);co=np.cos(theta);si=np.sin(theta);cx,cy=382,334
  sx=np.rint(cx+co*(xx-cx)+si*(yy-cy)).astype(int);sy=np.rint(cy+(-si*(xx-cx)+co*(yy-cy))/.80).astype(int);sx=np.clip(sx,0,639);sy=np.clip(sy,0,639);out=sa[sy,sx];out[~allowed]=0
  ba=np.array(b);oldMask=sa[:,:,3]>0;ba[oldMask]=0;b=Image.alpha_composite(Image.fromarray(ba),Image.fromarray(out))
  old=eq;eq=Image.new('RGBA',old.size);eq.alpha_composite(old,(0,-5))
 im=Image.alpha_composite(eq,b);ba=np.array(b);orig=np.array(original);diff=np.any(ba!=orig,axis=2);allowed=np.zeros(diff.shape,bool);allowed[334:385,356:410]=True;assert not(diff&~allowed).any()
 qa.append({'frame':k,'outsideHandRegionExact':True,'changedBasePixels':int(diff.sum()),'gearAdditionalShift':[0,-5] if k in [0,7] else [0,0],'attackFramesExact':k not in [0,7]})
 if k not in [0,7]:assert np.array_equal(np.array(im),np.array(Image.open(V/'frames'/f'{k}.png')))
 b.save(P/'base'/f'{k}.png');eq.save(P/'gear'/f'{k}.png');im.save(P/'frames'/f'{k}.png');bg=Image.new('RGBA',(640,680),'#778899');bg.alpha_composite(im,(0,40));ImageDraw.Draw(bg).text((20,12),f'Nodachi 69 NORTH | pega interna e cabo elevado | quadro {k}',fill='white');bg.convert('RGB').save(P/'video'/f'{k}.png');small=Image.new('RGBA',im.size,'#778899');small.alpha_composite(im);sheet.paste(small.resize((320,320)).convert('RGB'),(k%4*320,k//4*320));ImageDraw.Draw(sheet).text((k%4*320+10,k//4*320+10),str(k),fill='white')
sheet.save(P/'TODOS8.png');json.dump(qa,open(P/'QA.json','w'),indent=2)
seq=[0]*12+list(range(8))*4+[7]*12
(P/'concat.txt').write_text(''.join(f"file '{(P/'video'/f'{k}.png').resolve()}'\nduration {1/12}\n" for k in seq))
json.dump({'change':'only resting0/7, own hand tilted inward8deg progressively from fixed wrist; handle elevated5px','source':'original connected hand from V5; no donor transplant','sampling':'nearest original pixels, no blur or paint','limits':'2D inclination, not new 3D palm perspective','status':'candidate for user review'},open(P/'RECIPE.json','w'),indent=2)
o=Image.new('RGB',(800,400),'#778899')
for n,path in enumerate([V/'frames/0.png',P/'frames/0.png']):
 im=Image.open(path).crop((343,316,423,396)).resize((400,400),Image.Resampling.NEAREST);o.paste(im,(n*400,0),im);ImageDraw.Draw(o).text((n*400+10,10),'ANTES' if n==0 else 'DEPOIS',fill='white')
o.save(P/'DETALHE_PUNHO.png')
