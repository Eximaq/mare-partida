#!/bin/bash
set -e
cd /workspace/scratch/1b2385af8268
D=mosquete5-initial-only-v2
O=review-batch-audit/m5/frames/00.png
# Isolate existing equipment pixels, explicitly excluding original hand/arm.
magick -size 640x640 xc:black -fill white -draw 'polygon 216,392 216,379 234,354 251,348 252,356 248,364 252,369 259,374 268,373 273,366 276,376 266,382 246,384 231,394' -fill black -draw 'polygon 252,349 270,349 273,365 269,373 261,375 252,370 249,366 250,360' "$D/equipment-mask.png"
magick "$O" -alpha extract "$D/equipment-mask.png" -compose Multiply -composite "$D/equipment-alpha.png"
magick "$O" "$D/equipment-alpha.png" -alpha off -compose CopyOpacity -composite "$D/equipment-original.png"
# 20% scale about fixed original grip (258,365); no other pose changed.
magick "$D/equipment-original.png" -virtual-pixel transparent -filter point +distort SRT '258,365 1.2 0 258,365' -crop 640x640+0+0 +repage "$D/equipment-larger.png"
# Preserve original pixels except isolated equipment footprint.
magick "$D/equipment-mask.png" -negate "$D/keep-mask.png"
magick "$O" -alpha extract "$D/keep-mask.png" -compose Multiply -composite "$D/base-alpha.png"
magick "$O" "$D/base-alpha.png" -alpha off -compose CopyOpacity -composite "$D/base-preserved.png"
magick "$D/equipment-larger.png" "$D/base-preserved.png" -compose Over -composite "$D/frames/00.png"
magick "$D/frames/00.png" -crop 100x80+190+330 +repage -filter point -resize 800x640 "$D/qa/revised.png"
magick "$O" -alpha extract -threshold 0 "$D/keep-mask.png" -compose Multiply -composite "$D/protected-pixels.png"
magick "$D/frames/00.png" "$O" "$D/protected-pixels.png" -channel RGBA -fx 'u[2].r>0.5?u[1]:u[0]' "$D/frames/00.png"
