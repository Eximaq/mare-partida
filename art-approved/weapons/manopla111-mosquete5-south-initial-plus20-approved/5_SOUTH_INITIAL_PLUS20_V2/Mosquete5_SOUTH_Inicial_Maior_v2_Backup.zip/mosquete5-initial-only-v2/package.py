from pathlib import Path
import json,hashlib,subprocess,numpy as np
from PIL import Image
D=Path('mosquete5-initial-only-v2'); O=Path('review-batch-audit/m5')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=np.array(Image.open(O/'frames/00.png'));b=np.array(Image.open(D/'frames/00.png'));m=np.array(Image.open(D/'equipment-mask.png').convert('L'))>128
p=(a[:,:,3]>0)&~m
assert np.array_equal(a[p],b[p])
assert all(sha(O/f'frames/{i:02}.png')==sha(D/f'frames/{i:02}.png') for i in range(1,10))
report={'scope':'Only initial pose0; weapon +20 percent about original grip. All remaining poses including7 and9 byte-identical.','originalVisiblePixelsOutsideEquipmentMaskExact':True,'poses1to9ByteExact':True,'return7Changed':False,'generation':'Generated edit examined but not used: altered design/base. Exact original prop enlargement selected.','playbackWatched':False,'staticDetailReviewed':True,'knownTransition':'Initial0 intentionally larger than final9 per user clarification.'}
for name,order in [('normal',sum(([i for i in range(10) for _ in range(2)]+[9]*12 for _ in range(6)),[])),('lento',[i for _ in range(3) for i in range(10) for _ in range(6)])]:
 f=D/f'{name}.txt'; f.write_text(''.join(f"file '{(D/'video-frames'/f'{i:02}.png').resolve()}'\nduration {1/24}\n" for i in order))
 out=D/f'Mosquete5_SOUTH_Inicial_Maior_{name}_v2.mp4'
 subprocess.run(['ffmpeg','-v','error','-y','-f','concat','-safe','0','-i',str(f),'-r','24','-frames:v',str(len(order)),'-c:v','libx264','-crf','18','-pix_fmt','yuv420p',str(out)],check=True)
 raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(out),'-f','rawvideo','-pix_fmt','rgb24','-']); fs=np.frombuffer(raw,np.uint8).reshape(-1,640,640,3); assert len(fs)==len(order)
 refs=[np.array(Image.open(D/f'video-frames/{i:02}.png').convert('RGB')).astype(float) for i in range(10)]
 errs=[float(np.abs(fr.astype(float)-refs[i]).mean()) for fr,i in zip(fs,order)]
 assert max(errs)<3,(name,max(errs));report[name]={'decodedFrames':len(fs),'maxMeanErrorToExpectedFrame':max(errs),'orderChecked':True}
(D/'QA.json').write_text(json.dumps(report,indent=2));(D/'HASHES.json').write_text(json.dumps({str(p.relative_to(D)):sha(p) for p in D.rglob('*') if p.is_file()},indent=2))
print(json.dumps(report))
