from PIL import Image,ImageDraw
import pathlib,shutil,json,hashlib
D=pathlib.Path(__file__).parent;src=pathlib.Path('review-batch-audit/m111/gauntlet111-full-return-pilot-v1');out=D/'cycle';out.mkdir(exist_ok=True)
files=[D/'gauntlet111-rest-own-study-v3/phase0.png']+[src/f'sources/{i:02}.png' for i in range(1,12)]
for i,p in enumerate(files):shutil.copy2(p,out/f'{i:02}.png')
sheet=Image.new('RGB',(1920,760),'#657180');dr=ImageDraw.Draw(sheet)
for i,p in enumerate(files):
 im=Image.open(p).convert('RGBA');sheet.paste(im.resize((320,320)),((i%6)*320,(i//6)*380),im.resize((320,320)));dr.text(((i%6)*320+10,(i//6)*380+330),f'{i}: '+('+20% equipamento' if i==0 else 'inalterado'),fill='white')
sheet.save(D/'Preview.png')
order=json.loads((src/'MANIFEST.json').read_text())['order']
for t,i in enumerate(order):
 im=Image.open(files[i]).convert('RGBA');b=Image.new('RGBA',im.size,'#657180');b.alpha_composite(im);b.convert('RGB').save(out/f'tick{t:02}.png')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(files[11])==sha(out/'11.png')
(D/'QA.json').write_text(json.dumps({'item':111,'direction':'SOUTH','status':'initial pose only, user requested','scale':1.2,'posesChanged':[0],'pose11':'original7/return7 preserved byte-identically','return7sha256':sha(out/'11.png'),'fps':24,'ticks':20,'bodySourcesUnmodified':True},indent=2))

assert all(sha(src/f'sources/{i:02}.png')==sha(out/f'{i:02}.png') for i in range(1,12))
