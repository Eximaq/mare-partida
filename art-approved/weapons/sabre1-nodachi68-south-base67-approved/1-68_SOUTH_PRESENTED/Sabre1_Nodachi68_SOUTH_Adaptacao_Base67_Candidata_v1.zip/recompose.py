from PIL import Image
from pathlib import Path
import numpy as np
r=Path(__file__).parent
for item in [1,68]:
 for k in range(9):
  b=Image.open(r/"base"/f"{k}-body-visible.png").convert("RGBA")
  g=Image.open(r/str(item)/f"{k}-equipment.png").convert("RGBA")
  f=Image.open(r/"base"/f"{k}-foreground.png").convert("RGBA")
  out=Image.alpha_composite(Image.alpha_composite(b,g),f)
  assert np.array_equal(np.array(out),np.array(Image.open(r/str(item)/f"{k}-composite.png")))
print("18 compositions exact; not runtime validation")
