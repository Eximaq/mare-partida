from PIL import Image,ImageOps
from pathlib import Path
import numpy as np
from scipy.ndimage import distance_transform_edt
p=Path('front-adapt-audit/restored/Manoplas109_Repouso_Estudo_Preservado_v1/gauntlet109-rest-own-study-v1');src=Image.open(p/'sources/rest109.png').convert('RGBA');base=Image.open(p/'sources/body00.png').convert('RGBA');layer=Image.new('RGBA',base.size)
k=.0525
for x,flip in [(265,False),(385,True)]:
 im=src.resize((round(src.width*k),round(src.height*k)),Image.Resampling.NEAREST)
 if flip:im=ImageOps.mirror(im)
 layer.alpha_composite(im,(round(x-(src.width-480 if flip else 480)*k),round(333.7-230*k+6)))
comp=Image.alpha_composite(base,layer);a=np.array(comp).astype(int);ba=np.array(base);la=np.array(layer)
skin=(a[:,:,0]>a[:,:,1]+20)&(a[:,:,1]>a[:,:,2]+10)&(a[:,:,0]>100)&(a[:,:,3]>0)
region=np.zeros((640,640),bool);region[343:385,245:285]=True;region[343:385,370:406]=True
print('visible',np.argwhere(skin&region).tolist())
dist,ix=distance_transform_edt(la[:,:,3]<220,return_indices=True)
fill=skin&region&(dist<=6)
la[fill]=la[ix[0][fill],ix[1][fill]]
Image.fromarray(la).save('refazer10917/v3/overlay.png');out=Image.alpha_composite(base,Image.fromarray(la));out.save('refazer10917/v3/initial.png');out.crop((235,320,415,410)).resize((1080,540),Image.Resampling.NEAREST).save('/tmp/109v3.png')
print('fillPixels',fill.sum());aa=np.array(out).astype(int);rem=(aa[:,:,0]>aa[:,:,1]+20)&(aa[:,:,1]>aa[:,:,2]+10)&(aa[:,:,0]>100)&(aa[:,:,3]>0)&region;print('remaining',np.argwhere(rem).tolist())
