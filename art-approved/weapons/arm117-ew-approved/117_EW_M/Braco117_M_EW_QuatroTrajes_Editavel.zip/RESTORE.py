from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json
p=Path(__file__).parent;t=p/'template112';out=p/'male';out.mkdir(exist_ok=True)
qa=[]
for k in range(8):
 s=Image.open(p/f'original/117/v1/east/frames/{k:02}.png').convert('RGBA');a=np.array(s);g=np.array(Image.open(p/f'original/117/v1/east/layers/{k:02}-right-gear.png').convert('RGBA'))[:,:,3]>0
 for c in [151,158,165,179]:
  d=out/str(c);d.mkdir(exist_ok=True);cl=Image.open(t/f'{c}/{k}-cloth.png').convert('RGBA');r=np.array(Image.alpha_composite(s,cl));m=np.array(Image.open(t/f'{c}/{k}-ownership.png'))>0;m|=g;r[m]=a[m];r[:205]=a[:205];Image.fromarray(r).save(d/f'{k}-east.png');Image.fromarray(r[:,::-1]).save(d/f'{k}-west.png');qa.append({'pose':k,'outfit':c,'gearExact':bool(np.array_equal(a[g],r[g])),'headExact':bool(np.array_equal(a[:205],r[:205]))})
json.dump(qa,open(out/'QA.json','w'),indent=2)
o=Image.new('RGB',(1600,960),'#667788');dr=ImageDraw.Draw(o)
for row,c in enumerate([151,158,165,179]):
 for k in range(8):
  a=Image.open(out/f'{c}/{k}-east.png').resize((200,200));o.paste(a,(k*200,row*240),a);dr.text((k*200,row*240+205),f'{c} pose{k}',fill='white')
o.save(out/'CONTACT.png')
