from pathlib import Path
from PIL import Image,ImageOps
import json
p=Path(__file__).parent;out=p/'restored';out.mkdir(exist_ok=True);checks=[]
for c in [151,158,165,179]:
 for k in range(8):
  im=Image.alpha_composite(Image.open(p/f'{c}/{k}-base.png').convert('RGBA'),Image.open(p/f'{c}/{k}-equipment.png').convert('RGBA'))
  for d,a in [('east',im),('west',ImageOps.mirror(im))]:
   a.save(out/f'{c}-{k}-{d}.png');checks.append({'outfit':c,'pose':k,'direction':d,'exactRGBA':a.tobytes()==Image.open(p/f'{c}/{k}-{d}.png').tobytes()})
(p/'RESTORE_QA.json').write_text(json.dumps(checks,indent=2));assert all(x['exactRGBA'] for x in checks);print('64 frames restored exactly')
