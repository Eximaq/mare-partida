# Item 128: NORTH, historical-v1

9 source poses. Frame, source, layer and mask PNG files are byte-identical to the historical archive. The normal preview is also byte-identical. No image was regenerated or repainted for this package.

Use frames/ as the authoritative archived visual sequence. Additional source images and layers are preserved as supporting material; SOURCE_RECIPE.json is a portable description, not a new runtime implementation. TIMING.json distinguishes source timing from preview holds and repeats.

- Historical nine-pose generated preview. Body and equipment are not pixel-exact copies of the original base.
- Raw source alpha is preserved. Transparency, continuous-playback fluency and runtime integration are not certified.
- Pose 8 is not pixel-identical to pose 0. No seamless gameplay loop is asserted.

This archive does not change game runtime assets. SHA256.json verifies every included file except itself.
