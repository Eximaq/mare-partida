# Item 0: NORTH, original-restored-v2

8 source poses. Frame, source, layer and mask PNG files are byte-identical to the historical archive. The normal preview is also byte-identical. No image was regenerated or repainted for this package.

Use frames/ as the authoritative archived visual sequence. Additional source images and layers are preserved as supporting material; SOURCE_RECIPE.json is a portable description, not a new runtime implementation. TIMING.json distinguishes source timing from preview holds and repeats.

- Exact restored source pixels and historical one-shot timing are archived without new poses or redrawing.
- Archive approval covers the shown visual version. Gameplay fluency, rigging, collision and production integration remain unverified.

This archive does not change game runtime assets. SHA256.json verifies every included file except itself.
