from PIL import Image
from pathlib import Path
import numpy as np,json,shutil
p=Path(__file__).parent;old=p.parent/'rifle-base-v2';s=Image.open(p/'source4-front-existing.png').convert('RGBA');S=np.array([[230,950],[450,1850]],float);T={'4':[[287,267],[325,291]],'R':[[292,270],[329,298]]};qa=[]
for k,t in T.items():
 t=np.array(t,float);u=S[1]-S[0];v=t[1]-t[0];a=np.dot(u,v)/np.dot(u,u);b=(u[0]*v[1]-u[1]*v[0])/np.dot(u,u);A=np.array([[a,-b],[b,a]]);trans=t[0]-A@S[0];iv=np.linalg.inv(A);o=-iv@trans;eq=s.transform((640,640),Image.Transform.AFFINE,tuple([*iv[0],o[0],*iv[1],o[1]]),Image.Resampling.BICUBIC)
 base=Image.open(old/f'{k}-backing.png').convert('RGBA');hands=Image.open(old/f'{k}-hands.png').convert('RGBA');out=base.copy();out.alpha_composite(eq);out.alpha_composite(hands);out.save(p/f'{k}.png');eq.save(p/f'{k}-equipment.png');base.save(p/f'{k}-backing.png');hands.save(p/f'{k}-hands.png');qa.append({'state':k,'sourceAnchors':S.tolist(),'targetAnchors':t.tolist(),'transform':A.tolist(),'translation':trans.tolist(),'operation':'existing intact front source uniform similarity only; no new art or silhouette edits'})
sheet=Image.new('RGB',(1600,640),(70,75,80))
for j,k in enumerate(['0','1','2','4','R']):
 im=Image.open(p/f'{k}.png').convert('RGBA');bg=Image.new('RGBA',im.size,(70,75,80,255));bg.alpha_composite(im);sheet.paste(bg.resize((320,320)),(j*320,0));sheet.paste(bg.crop((235,220,435,365)).resize((320,232)),(j*320,350))
sheet.save(p/'ALL5.jpg');(p/'FRONT_RECIPE.json').write_text(json.dumps(qa,indent=2))
