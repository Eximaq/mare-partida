from PIL import Image,ImageDraw
from pathlib import Path
import subprocess,json,zipfile,hashlib,numpy as np
p=Path(__file__).parent;old=p.parent/'rifle-base-v2';order=[]
for k,n in zip(['0','1','2','4','R','4','2','1','0'],[8,3,3,4,2,3,4,4,12]):order += [k]*n
qa={'idleByteExact':(p/'0.png').read_bytes()==(old/'0.png').read_bytes(),'allBodyAndHandsExact':all(Image.open(p/f'{k}-{s}.png').tobytes()==Image.open(old/f'{k}-{s}.png').tobytes() for k in ['0','1','2','4','R'] for s in ['backing','hands']),'newGeneration':False,'frontSourceSHA256':hashlib.sha256((p/'source4-front-existing.png').read_bytes()).hexdigest(),'clock':'43ticks/24fps identical prior113/116','frameDecodeOnly':True}
for i,k in enumerate(order):
 im=Image.open(p/f'{k}.png');bg=Image.new('RGBA',im.size,(70,75,80,255));bg.alpha_composite(im);ImageDraw.Draw(bg).text((18,18),'Arma 4 | SOUTH | Cano frontal existente + base preservada',fill='white');bg.convert('RGB').save(p/f'video-{i:03}.png')
subprocess.run(['ffmpeg','-y','-loglevel','error','-framerate','24','-i',str(p/'video-%03d.png'),'-vf','loop=loop=3:size=43:start=0','-frames:v','172','-c:v','libx264','-pix_fmt','yuv420p',str(p/'Mosquete4_SOUTH_CanoFrontal_CicloCompleto_Candidato.mp4')],check=True)
(p/'QA.json').write_text(json.dumps(qa,indent=2));print(qa)
