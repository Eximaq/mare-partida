Arma4 Mosquete de Conves, SOUTH. Piloto M151/157.
Idle0 preservado byte-exato do piloto aceito como base. Estados0/1/2 identicos ao v2; somente equipamento4/R usa perspectiva frontal pre-existente recuperada da Library (fonte08/11, SHA73b453ff48fc2889c3e3e8e6c3bfb11752e0550917631a6628778e182b56f215).
Sem nova geracao. Nenhuma edicao ou repeticao da perspectiva posterior recusada. Registros da recusa posterior ainda sem request original; a fonte frontal intacta e anterior estava disponivel como candidato independente.
Todos backings e maos identicos a v2. Relogio original0,1,2,4,R,4,2,1,0 com ticks8,3,3,4,2,3,4,4,12 a24fps. Video repete4vezes. Sem runtime/rig/VFX ou anatomia oculta certificados. RESTORE.py reconstrui5quadros exatos.
