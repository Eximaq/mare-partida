from pathlib import Path
from PIL import Image
import json,hashlib
p=Path(__file__).parent
for k in ['0','1','2','4','R']:
 im=Image.open(p/f'{k}-backing.png').convert('RGBA');im.alpha_composite(Image.open(p/f'{k}-equipment.png').convert('RGBA'));im.alpha_composite(Image.open(p/f'{k}-hands.png').convert('RGBA'));ref=Image.open(p/f'{k}.png').convert('RGBA');assert im.tobytes()==ref.tobytes();im.save(p/f'restored-{k}.png')
print('5/5 exact RGBA reconstruction')
