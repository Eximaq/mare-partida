from pathlib import Path
from PIL import Image
import numpy as np
p=Path(__file__).parent;n=0
for f in p.glob('frames/*/*/*-source.png'):
 stem=f.name[:-11];s=Image.open(f).convert('RGBA');a=np.array(s);s.alpha_composite(Image.open(f.with_name(stem+'-garment.png')).convert('RGBA'));o=np.array(s);m=np.array(Image.open(f.with_name(stem+'-protected.png')))>0;o[m]=a[m];assert np.array_equal(o,np.array(Image.open(f.with_name(stem+'-frame.png')))),str(f);n+=1
print(n,'states restored exactly')
