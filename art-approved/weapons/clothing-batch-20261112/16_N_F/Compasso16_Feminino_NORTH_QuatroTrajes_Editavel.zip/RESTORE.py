from pathlib import Path
from PIL import Image
import numpy as np
p=Path(__file__).parent;b=Image.open(p/'body.png').convert('RGBA');n=0
for f in p.glob('frames/*/*/*-overlay.png'):
 out=Image.alpha_composite(b,Image.open(f).convert('RGBA'));assert np.array_equal(np.array(out),np.array(Image.open(f.with_name(f.name.replace('-overlay',''))))),str(f);n+=1
print(n,'states restored exactly')
