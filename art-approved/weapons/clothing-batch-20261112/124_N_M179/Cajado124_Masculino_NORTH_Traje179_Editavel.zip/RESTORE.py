from pathlib import Path
from PIL import Image
import numpy as np
p=Path(__file__).parent
for k in range(9):
 a=Image.alpha_composite(Image.open(p/f'{k}-source.png'),Image.open(p/f'{k}-garment.png'));assert np.array_equal(np.array(a),np.array(Image.open(p/f'{k}.png'))),k
print('9 states restored exactly')
