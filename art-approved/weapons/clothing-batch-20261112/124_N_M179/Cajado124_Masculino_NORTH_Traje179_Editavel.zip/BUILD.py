from pathlib import Path
from PIL import Image,ImageDraw
import numpy as np,json
p=Path(__file__).parent;s=p/'sources';d=p/'candidate/M179';d.mkdir(parents=True,exist_ok=True)
def smooth(T,widths):
 a=np.array(Image.open(s/'179-sleeve.png'));T=np.array(T,float);t=np.linspace(0,1,121);control=2*T[1]-.5*(T[0]+T[2]);curve=(1-t[:,None])**2*T[0]+2*(1-t[:,None])*t[:,None]*control+t[:,None]**2*T[2];tangent=np.gradient(curve,axis=0);tangent/=np.linalg.norm(tangent,axis=1)[:,None];normal=np.stack([-tangent[:,1],tangent[:,0]],1);length=np.r_[0,np.cumsum(np.linalg.norm(np.diff(curve,axis=0),axis=1))];length/=length[-1];best=np.full((640,640),1e9);idx=np.zeros((640,640),int)
 for i,pt in enumerate(curve):
  dist=(X-pt[0])**2+(Y-pt[1])**2;m=dist<best;idx[m]=i;best[m]=dist[m]
 cross=(X-curve[idx,0])*normal[idx,0]+(Y-curve[idx,1])*normal[idx,1];along=(X-curve[idx,0])*tangent[idx,0]+(Y-curve[idx,1])*tangent[idx,1];u=length[idx];rad=np.interp(u,[0,.5,1],widths);keep=(abs(cross)<=rad)&~((idx==120)&(along>1))&~((idx==0)&(along< -7));sy=np.rint(198+u*83).astype(int);sx=np.zeros_like(sy,float)
 for row in np.unique(sy):
  v=np.where(a[row,:,3]>64)[0];v=v[(v>210)&(v<295)]
  if not len(v):continue
  m=sy==row;sx[m]=(v[0]+v[-1])/2+cross[m]/rad[m]*(v[-1]-v[0])/2
 out=a[sy,np.clip(np.rint(sx),0,511).astype(int)].copy();out[~keep]=0;return Image.fromarray(out)
Y,X=np.mgrid[:640,:640];board=Image.new('RGB',(1920,1920),'#777');qa=[]
rig=[[[355,260],[374,314],[393,346]],[[355,260],[377,303],[413,309]],[[355,260],[378,282],[408,272]],[[355,260],[380,273],[408,247]],[[351,251],[386,242],[407,213]],[[355,260],[380,270],[410,236]],[[355,260],[380,285],[405,265]],[[355,260],[376,309],[409,314]],[[355,260],[374,315],[400,355]]]
gearcoords=[((431,275),(381,423),(402,353)),((445,230),(398,374),(424,310)),((438,195),(391,345),(420,270)),((430,164),(402,313),(420,240)),((435,138),(401,284),(420,213)),((438,150),(402,305),(424,231)),((430,171),(390,333),(414,257)),((430,234),(387,382),(418,315)),((438,285),(381,433),(410,361))]
for k in range(9):
 raw=Image.open(s/f'{k}.png').convert('RGBA');a=np.array(raw);core=Image.new('RGBA',(640,640))
 for part in ['hem','core']:core.alpha_composite(Image.open(s/f'179-{part}.png'),(64,60))
 cloth=Image.new('RGBA',(640,640));cloth.alpha_composite(smooth([[282,260],[265,308],[258,351]],[20,17,12]));cloth.alpha_composite(smooth(rig[k],[21,19,12]));cloth.alpha_composite(core)
 (ox,oy),(bx,by),(hx,hy)=gearcoords[k];dx=bx-ox;dy=by-oy;t=np.clip(((X-ox)*dx+(Y-oy)*dy)/(dx*dx+dy*dy),0,1);gear=((X-ox-t*dx)**2+(Y-oy-t*dy)**2<8**2)|((X-ox)**2+(Y-oy)**2<37**2)
 keep=(gear&(a[:,:,3]>200))|((((X-hx)**2+(Y-hy)**2<17**2)|(Y<228))&(a[:,:,3]>0))
 ca=np.array(cloth);ca[keep]=0;cloth=Image.fromarray(ca);out=Image.alpha_composite(raw,cloth);raw.save(d/f'{k}-source.png');cloth.save(d/f'{k}-garment.png');out.save(d/f'{k}.png');Image.fromarray((keep*255).astype('uint8')).save(d/f'{k}-protected.png');board.paste(out,(k%3*640,k//3*640),out);qa.append({'pose':k,'sourceOutsideClothExact':bool(np.array_equal(np.array(out)[ca[:,:,3]==0],a[ca[:,:,3]==0]))})
board.save(p/'M179_GATE.png');(p/'QA.json').write_text(json.dumps(qa,indent=2))
