from pathlib import Path
from PIL import Image,ImageOps
import numpy as np
p=Path(__file__).parent
for c in [151,158,165,179]:
 for k in range(8):
  s=Image.open(p/f'source-{k}.png').convert('RGBA');a=np.array(Image.alpha_composite(s,Image.open(p/f'M{c}/{k}-cloth.png')));raw=np.array(s);keep=np.array(Image.open(p/f'M{c}/{k}-protected.png'))>0;a[keep]=raw[keep];a[:205]=raw[:205];im=Image.fromarray(a)
  assert np.array_equal(a,np.array(Image.open(p/f'M{c}/{k}-east.png'))),(c,k)
  assert np.array_equal(np.array(ImageOps.mirror(im)),np.array(Image.open(p/f'M{c}/{k}-west.png'))),(c,k,'west')
print('64 states restored exactly')
