from pathlib import Path
from PIL import Image
import numpy as np
p=Path(__file__).parent;n=0
for q in (p/'frames').glob('*/*'):
 for k in range(8):
  src=Image.open(q/f'{k}-source.png').convert('RGBA');im=src.copy();im.alpha_composite(Image.open(q/f'{k}-garment.png'));a=np.array(im);original=np.array(src);keep=np.array(Image.open(q/f'{k}-ownership.png'))>0;a[keep]=original[keep];assert np.array_equal(a,np.array(Image.open(q/f'{k}.png')));n+=1
print(n,'states RGBA exact')
