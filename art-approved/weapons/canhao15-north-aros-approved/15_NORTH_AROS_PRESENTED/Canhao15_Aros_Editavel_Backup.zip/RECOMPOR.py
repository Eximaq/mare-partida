from PIL import Image
from pathlib import Path
p=Path(__file__).resolve().parent
for k in range(8):
 Image.alpha_composite(Image.open(p/f'base{k}.png').convert('RGBA'), Image.open(p/f'camada{k}.png').convert('RGBA')).save(p/f'frame{k}.png')
