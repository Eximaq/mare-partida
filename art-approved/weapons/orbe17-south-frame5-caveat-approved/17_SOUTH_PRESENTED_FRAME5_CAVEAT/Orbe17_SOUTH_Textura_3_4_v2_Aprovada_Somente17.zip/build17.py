from PIL import Image,ImageDraw
from pathlib import Path
p=Path('refazer10917/delivery/Orbe17_SOUTH_Revisao_8Quadros/originais')
source=Image.open('front-adapt-audit/restored/Orbe17_Checkpoint_Parcial_v3/rest0-own-visible-v2/composite.png').convert('RGBA')
# Only orb face, excluding all hand pixels; outer gold rim and grip untouched.
src=source.crop((372,350,393,371))
mask=Image.new('L',(21,21));ImageDraw.Draw(mask).ellipse((1,1,19,19),fill=255);src.putalpha(mask)
for i,c,r in [(3,(337,282),11),(4,(338,268),11)]:
 im=Image.open(p/f'{i}.png').convert('RGBA');patch=src.resize((r*2+1,r*2+1),Image.Resampling.NEAREST);im.alpha_composite(patch,(c[0]-r,c[1]-r));im.save(f'refazer10917/v2/17frame{i}.png')
 im.crop((300,240,380,320)).resize((640,640),Image.Resampling.NEAREST).save(f'/tmp/17new{i}.png')
